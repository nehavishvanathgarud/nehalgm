# LGM_Task2
Image to Pencil Sketch with Python
