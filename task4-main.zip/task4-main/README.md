# LGM_Task4
Prediction using Decision Tree  Algorithm
